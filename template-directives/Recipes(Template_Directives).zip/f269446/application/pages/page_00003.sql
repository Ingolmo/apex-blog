prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.8'
,p_default_workspace_id=>19699361431489317661
,p_default_application_id=>269446
,p_default_id_offset=>0
,p_default_owner=>'JUAN'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Classic Report'
,p_alias=>'CLASSIC-REPORT'
,p_step_title=>'Classic Report'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(84641641086816579246)
,p_name=>'Recipes'
,p_template=>4072358936313175081
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'TABLE'
,p_query_table=>'RECIPES'
,p_include_rowid_column=>false
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84641641442215579250)
,p_query_column_id=>1
,p_column_alias=>'RECIPE_ID'
,p_column_display_sequence=>0
,p_column_heading=>'Recipe ID'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_hidden_column=>'Y'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84641641883418579251)
,p_query_column_id=>2
,p_column_alias=>'RECIPE_NAME'
,p_column_display_sequence=>20
,p_column_heading=>'Recipe Name'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84641642213967579251)
,p_query_column_id=>3
,p_column_alias=>'CATEGORY'
,p_column_display_sequence=>30
,p_column_heading=>'Category'
,p_column_alignment=>'CENTER'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84641642642637579251)
,p_query_column_id=>4
,p_column_alias=>'INGREDIENTS'
,p_column_display_sequence=>40
,p_column_heading=>'Ingredients'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{if INGREDIENTS/}',
'  <ul class="t-Tags">',
'    {loop "," INGREDIENTS/}',
'      <li class="t-Tags-item">',
'        <span class="t-Tags-label">&APEX$ITEM.</span>',
'      </li>',
'    {endloop/}',
'  </ul>',
'{else/}',
'  <span class="u-muted">Sin ingredientes</span>',
'{endif/}'))
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84641643019310579252)
,p_query_column_id=>5
,p_column_alias=>'COOK_TIME'
,p_column_display_sequence=>50
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84641643470679579252)
,p_query_column_id=>6
,p_column_alias=>'DIFFICULTY'
,p_column_display_sequence=>60
,p_default_sort_column_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84641643807895579252)
,p_query_column_id=>7
,p_column_alias=>'IS_FEATURED'
,p_column_display_sequence=>100
,p_column_heading=>'Featured'
,p_column_alignment=>'CENTER'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>'STATIC:Yes;Y,No;N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84641644249525579252)
,p_query_column_id=>8
,p_column_alias=>'IMAGE_URL'
,p_column_display_sequence=>10
,p_column_heading=>'Image'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{with/}',
'  TYPE:=IMAGE',
'  IMAGE:=#IMAGE_URL#',
'  SIZE:=t-Avatar--xl',
'  SHAPE:=t-Avatar--square',
'{apply THEME$AVATAR/}'))
,p_column_alignment=>'CENTER'
,p_default_sort_column_sequence=>1
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(87783233786354900301)
,p_query_column_id=>9
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>90
,p_column_heading=>'info'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{if COOK_TIME/}',
unistr('  \23F1 #COOK_TIME# min'),
'{else/}',
'  <span class="u-muted">n/d</span>',
'{endif/}',
unistr(' \2022'),
'{case DIFFICULTY/}',
unistr('  {when F\00E1cil/}<span class="u-success-text">F\00E1cil</span>'),
'  {when Medio/}<span class="u-warning-text">Medio</span>',
unistr('  {when Dif\00EDcil/}<span class="u-danger-text">Dif\00EDcil</span>'),
'{endcase/}'))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(84641644650278579253)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(84641622350774579210)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp.component_end;
end;
/
