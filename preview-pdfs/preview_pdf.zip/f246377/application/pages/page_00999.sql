prompt --application/pages/page_00999
begin
--   Manifest
--     PAGE: 00999
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>19699361431489317661
,p_default_application_id=>246377
,p_default_id_offset=>0
,p_default_owner=>'JUAN'
);
wwv_flow_imp_page.create_page(
 p_id=>999
,p_name=>'Stream Document'
,p_alias=>'STREAM-DOCUMENT'
,p_step_title=>'Stream Document'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>2979075366320325194
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(87783238478865900348)
,p_name=>'P999_DOC_ID'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(87783238539571900349)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create URL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_blob      blob;',
'  l_mime      varchar2(255);',
'  l_filename  varchar2(255);',
'begin',
'  select file_blob, mime_type, file_name',
'    into l_blob, l_mime, l_filename',
'    from app_docs',
'   where doc_id = :P999_DOC_ID;',
'',
'  sys.htp.init;',
'  owa_util.mime_header(nvl(l_mime,''application/pdf''), false);',
'',
'  -- Important: serve inline so browsers can preview',
'  htp.p(''Content-Length: '' || dbms_lob.getlength(l_blob));',
'  htp.p(''Content-Disposition: inline; filename="'' || replace(l_filename,''"'','''') || ''"'');',
'',
'  owa_util.http_header_close;',
'',
'  wpg_docload.download_file(l_blob);',
'  apex_application.stop_apex_engine;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>87783238539571900349
);
wwv_flow_imp.component_end;
end;
/
