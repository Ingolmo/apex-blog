prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>19699361431489317661
,p_default_application_id=>246377
,p_default_id_offset=>0
,p_default_owner=>'JUAN'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'PDF Preview'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(130614839835577705497)
,p_plug_name=>unistr('Previsualizaci\00F3n de Documentos')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(130930302280109918515)
,p_plug_name=>'R_PREVIEW_DIALOG'
,p_title=>unistr('Previsualizaci\00F3n mediante <iframe>')
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size720x480'
,p_plug_template=>2672673746673652531
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_04'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<iframe',
'  title="Document Preview"',
'  src="&P1_DOC_URL."',
'  style="width:100%; height:80vh; border:0;"',
'  loading="lazy">',
'</iframe>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(261362663077666242225)
,p_name=>'R_DOCUMENTS'
,p_title=>'Documentos'
,p_template=>4072358936313175081
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'  d.doc_id,',
'  d.file_name,',
'  d.created_on',
'from app_docs d',
'order by created_on desc'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(130713008226066007061)
,p_query_column_id=>1
,p_column_alias=>'DOC_ID'
,p_column_display_sequence=>40
,p_column_heading=>'&lt;object&gt;'
,p_column_link=>'javascript:void(0);'
,p_column_linktext=>'<span class="fa fa-eye" aria-hidden="true"></span>'
,p_column_link_attr=>'class="js-doc-preview" data-doc-id="#DOC_ID#"'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(130713008672375007062)
,p_query_column_id=>2
,p_column_alias=>'FILE_NAME'
,p_column_display_sequence=>20
,p_column_heading=>'File Name'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(130713009043880007062)
,p_query_column_id=>3
,p_column_alias=>'CREATED_ON'
,p_column_display_sequence=>10
,p_column_heading=>'Created On'
,p_column_format=>'DD/MM/YYYY'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(130650989666923278416)
,p_query_column_id=>4
,p_column_alias=>'DERIVED$01'
,p_column_display_sequence=>50
,p_column_heading=>'&lt;iframe&gt;'
,p_column_link=>'javascript:void(0);'
,p_column_linktext=>'<span class="fa fa-external-link" aria-hidden="true"></span>'
,p_column_link_attr=>'class="js-doc-preview-inline" data-doc-id="#DOC_ID#"'
,p_column_alignment=>'CENTER'
,p_derived_column=>'Y'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(261364003765423286646)
,p_plug_name=>'R_PREVIEW'
,p_title=>unistr('Previsualizaci\00F3n mediante &lt;object&gt;')
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<object',
'  id="docObj"',
'  title="Document Preview"',
'  type="application/pdf"',
'  data=""',
'  style="width:100%; height:75vh; border:0;">',
'  <p>',
'    No se ha podido previsualizar el Documento.',
unistr('    <a id="docFallback" href="#" target="_blank" rel="noopener">Abrir en pesta\00F1a nueva</a>'),
'  </p>',
'</object>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(87783237351474900337)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(130614839835577705497)
,p_button_name=>'UPLOAD_DOCUMENT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--simple'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Upload Document'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:2::'
,p_icon_css_classes=>'fa-folder-arrow-up'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(261363997731388285465)
,p_name=>'P1_DOC_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(261362663077666242225)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(261364004250111286651)
,p_name=>'P1_DOC_URL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(261364003765423286646)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(130650989247859278412)
,p_name=>'Preview using <object>'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.js-doc-preview'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(130650989383929278413)
,p_event_id=>wwv_flow_imp.id(130650989247859278412)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_DOC_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.dataset.docId'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(130650989455210278414)
,p_event_id=>wwv_flow_imp.id(130650989247859278412)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P1_DOC_URL :=',
'  apex_page.get_url(',
'    p_page   => 999,',
'    p_items  => ''P999_DOC_ID'',',
'    p_values => :P1_DOC_ID',
'  );'))
,p_attribute_02=>'P1_DOC_ID'
,p_attribute_03=>'P1_DOC_URL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(130650989579592278415)
,p_event_id=>wwv_flow_imp.id(130650989247859278412)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const url = apex.item("P1_DOC_URL").getValue();',
'',
'const obj = document.getElementById("docObj");',
'const a   = document.getElementById("docFallback");',
'',
'if (url && obj) {',
'  // Force reload in many browsers',
'  obj.data = "";',
'  obj.data = url;',
'',
'  if (a) a.href = url;',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(130930301217779918505)
,p_name=>'Preview using <iframe>'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.js-doc-preview-inline'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(130930301316213918506)
,p_event_id=>wwv_flow_imp.id(130930301217779918505)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_DOC_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.dataset.docId'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(130930301442565918507)
,p_event_id=>wwv_flow_imp.id(130930301217779918505)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P1_DOC_URL :=',
'  apex_page.get_url(',
'    p_page   => 999,',
'    p_items  => ''P999_DOC_ID'',',
'    p_values => :P1_DOC_ID',
'  );'))
,p_attribute_02=>'P1_DOC_ID'
,p_attribute_03=>'P1_DOC_URL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(130930302472283918517)
,p_event_id=>wwv_flow_imp.id(130930301217779918505)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(130930302280109918515)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(130930302386281918516)
,p_event_id=>wwv_flow_imp.id(130930301217779918505)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(130930302280109918515)
);
wwv_flow_imp.component_end;
end;
/
