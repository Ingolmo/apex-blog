prompt --application/shared_components/navigation/breadcrumbentry
begin
--   Manifest
--     BREADCRUMB ENTRY: 
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>19699361431489317661
,p_default_application_id=>246377
,p_default_id_offset=>0
,p_default_owner=>'JUAN'
);
null;
wwv_flow_imp.component_end;
end;
/
