prompt --application/shared_components/navigation/lists/home_navigation_list
begin
--   Manifest
--     LIST: Home Navigation List
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>19699361431489317661
,p_default_application_id=>246377
,p_default_id_offset=>0
,p_default_owner=>'JUAN'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(130625116553711940998)
,p_name=>'Home Navigation List'
,p_list_status=>'PUBLIC'
,p_version_scn=>15706552953762
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(130625117178188940999)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'&lt;iframe&gt;'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-code'
,p_list_text_01=>'Elemento &lt;iframe&gt; en HTML'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(130625117525509940999)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'PDF.js'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-robot'
,p_list_text_01=>unistr('Uso de una librer\00EDa JavaScritp')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
